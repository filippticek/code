package hr.fer.ilj.lectures;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Predavanje6LecturesApplication {

	public static void main(String[] args) {
		SpringApplication.run(Predavanje6LecturesApplication.class, args);
	}

}
